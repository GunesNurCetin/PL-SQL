# 🎓 PL/SQL Mini Proje: Öğrenci Yönetim Sistemi
Bu proje, PL/SQL temellerini öğrenmek için hazırlanmış örnek bir öğrenci yönetim sistemidir.
## 🚀 İçerik
1. Tabloları oluşturma
2. Örnek veriler ekleme
3. Öğrenci ekleme prosedürü
4. Not girme prosedürü
5. Ortalama ve geçme durumunu hesaplama
6. Sonuçları listeleme
## 💻 Çalıştırma
Tüm `.sql` dosyaları Oracle Live SQL üzerinde sırasıyla çalıştırılabilir:
https://livesql.oracle.com
